import com.alibaba.nonda.modular.BundleContainer;
import com.alibaba.nonda.modular.context.BundleContext;
import com.alibaba.nonda.modular.impl.Bundle;
import com.alibaba.nonda.modular.impl.BundleContainerImpl;
import com.aliyun.ace4j.nginx.NginxService;
import com.aliyun.ace4j.services.common.utils.timer.TimerTasks;
import com.aliyun.ace4j.share.ots.sdk.api.OTSService;
import com.aliyun.ace4j.shared.monitor.services.MonitorService;

public class Test {
    public static void main(String[] args) {
        BundleContainer container = new BundleContainerImpl();
        container.start();

        Bundle bundle = container.get("ace4j.shared.monitor");
        BundleContext context = bundle.getBundleContext();

        context.getBean("monitorService");
        context.getBean("nginxService");
        context.getBean("otsService");
        context.getBean("timerTasks");
    }
}
