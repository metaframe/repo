#!/bin/bash

[ -z "$1" ] && { echo No find file pattern! ; exit 1; }  
[ ! -d  "$1" ] && { echo "${1} is not a directory" ; exit 1; }  

cd `dirname $0`

webRoot="$1"
LIBCLASSPATH=`echo ${webRoot}/lib/*.jar | tr ' ' ':'`
export CLASSPATH=${webRoot}/classes:$LIBCLASSPATH:.
echo ${CLASSPATH}

javac Test.java
java Test
